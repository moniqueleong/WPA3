<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8">
    <title>Cart</title>

    <!-- Keep wireframe.css for debugging, add your css to style.css -->
    <link id='wireframecss' type="text/css" rel="stylesheet" href="../wireframe.css" disabled>
    <link id='stylecss' type="text/css" rel="stylesheet" href="css/style.css">
    <script src='../wireframe.js'></script>
	
	<?php
		session_start();
		if (isset( $_POST['id'], $_POST['price'], $_POST['qty'], $_POST['oid'])) {
		  
		  $id=$_POST['id'];
		  $oid=$_POST['oid'];
		  $qty=$_POST['qty'];
		  $price=$_POST['price'];
		  
		  $_SESSION['cart'][$id]['oid'] = $oid;
		  $_SESSION['cart'][$id]['qty'] = $qty;
		  $_SESSION['cart'][$id]['price'] = $price;
		  // redirection BEFORE any HTML is outputted
		  //header("Location: cart.php");
		}
	?>
	
</head>

<body>


    <header>
        <h1><img src="../../media/logo.png" style="height:100px"></h1>

    </header>

    <nav>
        <li><a href="index.php">Home</a></li>
        <li><a href="login.php">Log in</a></li>
        <li><a href="product.php">Products</a></li>
        <li style="float:right"><a href="cart.php">Cart</a></li>

    </nav>

    <main>
	
	<div class="gallery2">
             <img class="cartcssIMG" src="../../media/roses.png" alt="Roses" width="100">
			 <p class="fontCarty">Your items:</p>
			<label for="name">Quantity</label>
        <input type="number" min="1" name="qty" id="rabbitQTY" value= "<?php echo $_SESSION['cart']['R123']['qty']; ?>">
					<br>
					<label> Colour: <?php echo $_SESSION['cart']['R123']['oid']; ?> </label>
					<br>
					<label> Price: <?php echo $_SESSION['cart']['R123']['price']*$_SESSION['cart']['R123']['qty']; ?> </label>
			
				


        </div>
		<form action="checkout.php" method="post">
		<button type="submit" class="shopButton">Go to checkout </button>
		</form>
		
		<form action="products.php" method="post">
		<button type="submit" class="shopButton" name='clear'>Clear Cart</button>
		</form>



    </main>

    <footer>
        <div>&copy;
            <script>
                document.write(2018);

            </script> Monique Leong</div>
        <div>Disclaimer: This website is not a real website and is being developed as part of a School of Science Web Programming course at RMIT University in Melbourne, Australia.</div>
        <div><button id='toggleWireframeCSS' onclick='toggleWireframe()'>Toggle Wireframe CSS</button></div>
    </footer>

</body>

</html>
