function categorySplitter (line)
{

	var categoryValue=['','','','','','',''];

	var i=0;
	
	for(j=0; j<line.length;j++)
	{
		
		if(line[j]==",")
		{
			i++;
		}
		else{
			categoryValue[i]=categoryValue[i]+line[j];
		}
	}
	
	
	return categoryValue;
}