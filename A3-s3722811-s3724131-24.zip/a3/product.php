<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8">
    <title>Home</title>

    <!-- Keep wireframe.css for debugging, add your css to style.css -->
    <link id='wireframecss' type="text/css" rel="stylesheet" href="../wireframe.css" disabled>
    <link id='stylecss' type="text/css" rel="stylesheet" href="css/style.css">
    <script src='../wireframe.js'></script>
	<script src='myscript.js'></script>
	
	<?php 
		if (!isset($_GET['id']))
		{
			 header("Location: products.php");
		}
	?>
	
	<script>

	var record= <?php
					$i=0;
					if ($file = fopen("products.csv", "r")) {
					while(!feof($file)) {
						$line [$i]= fgets($file);
						$i=$i+1;
					}
					fclose($file);
					echo json_encode($line);
					}	
				?>;
		
		var splittedRecords=[];
		for(i=0; i< record.length; i++)
		{
			splittedRecords[i]=categorySplitter(record[i]);
		}
		
		var productFirstRecord=0;
		for(i=0; i< splittedRecords.length; i++)
		{
			if(splittedRecords[i][0]=="<?php echo $_GET['id']; ?>")
			{
				productFirstRecord=i;
				break;
			}
				
		}
		
		//document.getElementById("blas").src=splittedRecords[productFirstRecord][6];
		
	</script>
	
	
</head>

<body>


    <header>
        <h1><img  src="../../media/logo.png" style="height:100px"></h1>

    </header>

    <nav>
		<li><a href="index.php">Home</a></li>
        <li><a href="login.php">Log in</a></li>
        <li><a href="product.php">Products</a></li>
        <li style="float:right"><a href="cart.php">Cart</a></li>
    </nav>

    <main>
<img id="blas" src="" style="height:300px; float:left; padding: 10px;">
<h2 id="title"> Roses </h2>
<p id="description">Our roses are delivered to our store fresh daily and come in a range of colours including white, red, pink.</p> </br>


<form action="cart.php" method="post">
<p id="priceLabel">Price: $10.00 </p><br><br>
<input type="hidden" id="productId" name="id" value="R123">
<input type="hidden" id="priceValue" name="price" value="10">
<select id='options' name="oid">
  </select>
  <br><br>
  
  Quantity:
  <input type="number" name="qty" min="1"><br><br>
<input type="submit" value="Add to Cart">
</form>

<script>
document.getElementById("blas").src=splittedRecords[productFirstRecord][6];
document.getElementById("title").innerHTML=splittedRecords[productFirstRecord][2];
document.getElementById("priceLabel").innerHTML="Price: $"+splittedRecords[productFirstRecord][5]+".00";
document.getElementById("priceValue").value=Number(splittedRecords[productFirstRecord][5]);
document.getElementById("description").innerHTML=splittedRecords[productFirstRecord][3];

var select=document.getElementById("options");
var option=null;
for (i=0; i<3; i++)
{
	option = document.createElement('option');
    option.value = splittedRecords[productFirstRecord+i][1];
    option.innerHTML = splittedRecords[productFirstRecord+i][4];
    select.appendChild(option);
}
</script>

    </main>

    <footer>
        <div>&copy;
            <script>
                document.write(2018);

            </script> Monique Leong</div>
        <div>Disclaimer: This website is not a real website and is being developed as part of a School of Science Web Programming course at RMIT University in Melbourne, Australia.</div>
        <div><button id='toggleWireframeCSS' onclick='toggleWireframe()'>Toggle Wireframe CSS</button></div>
    </footer>

</body>

</html>
