function categorySplitter (String Line)
{

	var categoryNames [6]= {"ID", "OID", "Title", "Description", "Option", "Price"}
	var categoryValue [6];

	int i=0; int j=0;
	while (i<=5)
	{
		while(line[j]!="\0")
		{
			
			if(line[j]==',')
			{
				i++;
			}
			else{
				categoryValue[i]=categoryValue[i]+line[j];
			}
			j++;
		}
	}
	
	return categoryValue;
}

var rose[6];
roses=categorySplitter("R123,RED,Roses,These are red roses ,red,10");
var lily[6];
lily=categorySplitter("R123,PNK,Roses,These are pink roses ,pink,10");
var white[6];
white=categorySplitter("R123,WHT,Roses,These are white roses,white,10");

